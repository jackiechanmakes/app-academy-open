import Showcase from './Showcase.js';
import './App.css'

function App() {
  return (
    <div className='background'>
      <Showcase />
    </div>
  );
}

export default App;
